package com.niit.mycartbackendproject.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserController {
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView checkUser(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {
		
		if (request.isUserInRole("ROLE_ADMIN")) {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String name = auth.getName(); // get logged in username
			session = request.getSession(true);
			session.setAttribute("loggedInUser", name);

			// session.invalidate();
			ModelAndView mv = new ModelAndView("Home");
			mv.addObject("isAdmin", "true");
			return mv;
		}
		else if(request.isUserInRole("ROLE_USER")) {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String name = auth.getName(); // get logged in username
			session = request.getSession(true);
			session.setAttribute("loggedInUser", name);
			ModelAndView m11 = new ModelAndView("Home");
			m11.addObject("display", "true");
			return m11;
		} else {
			ModelAndView mv = new ModelAndView("Home");
			mv.addObject("invalidCredentials", "true");
			mv.addObject("errorMessage", "Invalid Credentials.Please enter with a valid Credentials");
			return mv;

		}
		
		
	}
	@RequestMapping("/accessdenied")
	public ModelAndView fail2login() {
		ModelAndView mv = new ModelAndView("Home");
		
			mv.addObject("display", "true");
	
			mv.addObject("FailMessage", "you are not authorised to open this page");
		
		
		
		return mv;
	}
	
	
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public void logout(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws ServletException, IOException {
		HttpSession newsession = request.getSession(false);
		if (newsession != null) 
	    {
	         newsession.invalidate();

	    }
		response.sendRedirect("j_spring_security_logout");	
		}
	
	@RequestMapping("/logoutsuccess")
	public ModelAndView logoutsuccess() {
		ModelAndView mv = new ModelAndView("/Home");
		
			mv.addObject("display", "true");
	
			mv.addObject("logoutMessage", "You are successfully logged out");
			mv.addObject("loggedOut", "true");
		
		
		
		return mv;
	}
}
