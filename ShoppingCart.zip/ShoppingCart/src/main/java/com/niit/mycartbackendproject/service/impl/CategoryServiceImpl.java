package com.niit.mycartbackendproject.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.mycartbackendproject.dao.CategoryDao;
import com.niit.mycartbackendproject.model.Category;
import com.niit.mycartbackendproject.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
    private CategoryDao categoryDao;


	public List<Category> getCategoryList() {
		 return categoryDao.getCategoryList();
	}

	
	public Category getCategorybyId(int CategoryId) {
		 return categoryDao.getCategorybyId(CategoryId);
		
	}

	
	public Category getCategorybyName(String CategoryName) {
		 return categoryDao.getCategorybyName(CategoryName);
		
	}

	
	public void addCategory(Category Category) {
		  categoryDao.addCategory(Category);
		
	}
	
	public void updateCategory(Category Category) {
		  categoryDao.addCategory(Category);
		
	}

	public void deleteCategory(int categoryId) {
		categoryDao.deleteCategory(categoryId);
		
	}

	
	
}