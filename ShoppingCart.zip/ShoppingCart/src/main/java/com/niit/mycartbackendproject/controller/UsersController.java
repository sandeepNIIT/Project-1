package com.niit.mycartbackendproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.niit.mycartbackendproject.model.Customer;
import com.niit.mycartbackendproject.service.CustomerService;

public class UsersController {
	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public String listUsers(Model model) {
		
		model.addAttribute("AddUser", true);
		model.addAttribute("CustomerList", this.customerService.getAllCustomers());
		model.addAttribute("isAdminClickedUsers", "true");
		return "Home";
	}

	
	@RequestMapping(value = "/user/add", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("Customer") Customer Customer) {

		
		
		customerService.addCustomer(Customer);
			
		return "redirect:/users";
		

	}

	@RequestMapping(value="user/remove/{customerId}")
	public String removeUser(@PathVariable("customerId") int customerId, ModelMap model) throws Exception {

		try {
			customerService.deleteCustomer(customerId);
			
			model.addAttribute("message", "Successfully Added");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
	
		return "redirect:/users";
	}

	@RequestMapping(value="user/edit/{customerId}",method = RequestMethod.GET)
	public String editUser(@PathVariable("customerId") int customerId, Model model) {
		model.addAttribute("EditUser", true);
		model.addAttribute("Customer", this.customerService.getCustomerById(customerId));
		model.addAttribute("CustomerList", this.customerService.getAllCustomers());
		

		return "Home";
	}

	
	@RequestMapping(value="/user/edit",method = RequestMethod.POST)
	public String editUser(@ModelAttribute("Customer") Customer Customer,ModelMap model) {
		
		customerService.addCustomer(Customer);		
		model.addAttribute("customerList", this.customerService.getAllCustomers());
		model.addAttribute("isAdminClickedUsers", "true");
		 return "redirect:/users";
	}
	
}
