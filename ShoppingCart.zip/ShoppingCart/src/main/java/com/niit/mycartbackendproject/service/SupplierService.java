package com.niit.mycartbackendproject.service;

import java.util.List;

import com.niit.mycartbackendproject.model.Supplier;

public interface SupplierService {
	public List<Supplier> getSupplierList();

	public Supplier getSupplierbyId(int supplierId);
	
	public Supplier getSupplierbyName(String supplierName);

	public void addSupplier(Supplier supplier);
	
	public void updateSupplier(Supplier supplier);

	public String deleteSupplier(int supplierId);

}
