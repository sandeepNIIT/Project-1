package com.niit.mycartbackendproject.service;

import com.niit.mycartbackendproject.model.CustomerOrder;

public interface CustomerOrderService {

    void addCustomerOrder(CustomerOrder customerOrder);

    double getCustomerOrderGrandTotal(int cartId);
}
