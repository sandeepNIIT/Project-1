package com.niit.mycartbackendproject.service;


import java.util.List;

import com.niit.mycartbackendproject.model.Customer;

public interface CustomerService {

    void addCustomer(Customer customer);
    
    void updateCustomer(Customer customer);

    Customer getCustomerById(int customerId);

    List<Customer> getAllCustomers();
    
    void deleteCustomer(int customerId);

    Customer getCustomerByUsername(String username);

}
