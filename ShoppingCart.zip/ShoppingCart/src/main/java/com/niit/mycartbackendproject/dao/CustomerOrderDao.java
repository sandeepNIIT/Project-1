package com.niit.mycartbackendproject.dao;

import com.niit.mycartbackendproject.model.CustomerOrder;

public interface CustomerOrderDao {

    void addCustomerOrder(CustomerOrder customerOrder);
}
