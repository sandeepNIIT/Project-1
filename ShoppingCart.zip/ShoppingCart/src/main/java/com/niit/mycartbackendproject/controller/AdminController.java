package com.niit.mycartbackendproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.mycartbackendproject.model.Category;
import com.niit.mycartbackendproject.model.Customer;
import com.niit.mycartbackendproject.model.Product;
import com.niit.mycartbackendproject.model.Supplier;
import com.niit.mycartbackendproject.service.CategoryService;
import com.niit.mycartbackendproject.service.CustomerService;
import com.niit.mycartbackendproject.service.ProductService;
import com.niit.mycartbackendproject.service.SupplierService;

@Controller
public class AdminController {

	@Autowired
	private Product product;

	@Autowired
	private Supplier supplier;

	@Autowired
	private Category category;

	@Autowired
	private SupplierService supplierService;

	@Autowired
	private CategoryService categoryService;

	@Autowired
	private ProductService productService;
	@Autowired
	private Customer customer;
	@Autowired
	private CustomerService customerService;
	

	@RequestMapping("/manageCategories")
	public ModelAndView categories() {
		ModelAndView mv = new ModelAndView("/Home");
		mv.addObject("category", category);
		mv.addObject("AddCategory", true);
		mv.addObject("isAdminClickedCategories", "true");
		mv.addObject("categoryList", categoryService.getCategoryList());
		return mv;
	}

	@RequestMapping("/manageProducts")
	public ModelAndView suppliers() {
		ModelAndView mv = new ModelAndView("/Home");
		mv.addObject("product", product);
		mv.addObject("AddProduct", true);
		mv.addObject("isAdminClickedProducts", "true");
		mv.addObject("productList", productService.getProductList());
		return mv;
	}

	@RequestMapping("/manageSuppliers")
	public ModelAndView products() {
		ModelAndView mv = new ModelAndView("/Home");
		mv.addObject("supplier", supplier);
		mv.addObject("AddSupplier",true);
		mv.addObject("isAdminClickedSuppliers", "true");
		mv.addObject("supplierList", supplierService.getSupplierList());
		return mv;
	}

	@RequestMapping("/manageUsers")
	public ModelAndView users() {
		ModelAndView mv = new ModelAndView("/Home");
		mv.addObject("customer", customer);
		mv.addObject("AddUser", true);
		mv.addObject("isAdminClickedUsers", "true");
		mv.addObject("customerList", customerService.getAllCustomers());
		return mv;
	}

}
