package com.niit.mycartbackendproject.service;

import java.util.List;

import com.niit.mycartbackendproject.model.Category;

public interface CategoryService {
	public List<Category> getCategoryList();

	public Category getCategorybyId(int categoryId);
	
	public Category getCategorybyName(String categoryName);

	public void addCategory(Category category);
	
	public void updateCategory(Category category);

	public void deleteCategory(int categoryId);

}
