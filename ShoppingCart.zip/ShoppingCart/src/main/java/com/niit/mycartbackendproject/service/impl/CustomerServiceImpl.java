package com.niit.mycartbackendproject.service.impl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.mycartbackendproject.dao.CustomerDao;
import com.niit.mycartbackendproject.model.Customer;
import com.niit.mycartbackendproject.service.CustomerService;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService{

    @Autowired
    private CustomerDao customerDao;

    public void addCustomer(Customer customer){
        customerDao.addCustomer(customer);
    }
    
    public void updateCustomer(Customer customer){
        customerDao.addCustomer(customer);
    }

    public Customer getCustomerById(int customerId){
        return customerDao.getCustomerById(customerId);
    }

    public List<Customer> getAllCustomers(){
        return customerDao.getAllCustomers();
    }

    public Customer getCustomerByUsername (String username){
        return customerDao.getCustomerByUsername(username);
    }

	public void deleteCustomer(int customerId) {
		 customerDao.deleteCustomer(customerId);
		
	}


} // The End of Class;
