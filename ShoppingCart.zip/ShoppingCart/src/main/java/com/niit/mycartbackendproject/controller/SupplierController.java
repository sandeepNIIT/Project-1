package com.niit.mycartbackendproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.niit.mycartbackendproject.model.Supplier;
import com.niit.mycartbackendproject.service.SupplierService;

@Controller
public class SupplierController {
	
	@Autowired
private SupplierService supplierService;
	
	
	@RequestMapping(value = "/mansuppliers", method = RequestMethod.GET)
	public String listSuppliers(Model model) {
		
		model.addAttribute("supplierList", this.supplierService.getSupplierList());
		model.addAttribute("AddSupplier", true);
		model.addAttribute("isAdminClickedSuppliers", "true");
		return "Home";
	}
	
	//For add and update supplier both
	@RequestMapping(value= "/supplier/add", method = RequestMethod.POST)
	public String addSupplier(@ModelAttribute("supplier") Supplier supplier){
		supplierService.addSupplier(supplier);
		
		
		return "redirect:/mansuppliers";
		
	}
	
	@RequestMapping("supplier/remove/{supplierId}")
    public String removeSupplier(@PathVariable("supplierId") int supplierId,ModelMap model) throws Exception{
		
       try {
		supplierService.deleteSupplier(supplierId);
		model.addAttribute("message","Successfully Added");
	} catch (Exception e) {
		model.addAttribute("message",e.getMessage());
		e.printStackTrace();
	}
       //redirectAttrs.addFlashAttribute(arg0, arg1)
        return "redirect:/mansuppliers";
    }
 
    @RequestMapping("supplier/edit/{supplierId}")
    public String editSupplier(@PathVariable("supplierId") int supplierId, Model model){
    	
        model.addAttribute("supplier", this.supplierService.getSupplierbyId(supplierId));
        model.addAttribute("EditSupplier",true);
        model.addAttribute("supplierList", this.supplierService.getSupplierList());
        return "Home";
    }
	
    @RequestMapping(value="/supplier/edit",method = RequestMethod.POST)
	public String editProduct(@ModelAttribute("supplier") Supplier supplier,ModelMap model) {
		
		 supplierService.updateSupplier(supplier);
		model.addAttribute("supplierList", this.supplierService.getSupplierList());
		model.addAttribute("isAdminClickedProducts", "true");
		 return "redirect:/mansuppliers";
	}
	
}
