package com.niit.mycartbackendproject.dao;

import com.niit.mycartbackendproject.model.Cart;
import com.niit.mycartbackendproject.model.CartItem;

public interface CartItemDao {

    void addCartItem(CartItem cartItem);

    void removeCartItem(CartItem cartItem);

    void removeAllCartItems(Cart cart);

    CartItem getCartItemByProductId(int productId);
}
