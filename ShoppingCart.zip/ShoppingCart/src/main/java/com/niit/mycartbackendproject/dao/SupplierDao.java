package com.niit.mycartbackendproject.dao;

import java.util.List;

import com.niit.mycartbackendproject.model.Supplier;

public interface SupplierDao {
	public List<Supplier> getSupplierList();

	public Supplier getSupplierbyId(int supplierId);
	
	public Supplier getSupplierbyName(String supplierName);

	public void addSupplier(Supplier supplier);

	public void updateSupplier(Supplier supplier);
	
	public String deleteSupplier(int supplierId);

}
