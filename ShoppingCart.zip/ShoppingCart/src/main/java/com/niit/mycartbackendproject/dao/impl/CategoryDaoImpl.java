package com.niit.mycartbackendproject.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.mycartbackendproject.dao.CategoryDao;
import com.niit.mycartbackendproject.model.Category;

@Repository("categoryDao")
public class CategoryDaoImpl implements CategoryDao {
	
	
	@Autowired
	private SessionFactory sessionFactory;


	public CategoryDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Transactional
	public List<Category> getCategoryList() {
		
		
		List<Category> listCategory = (List<Category>) 
		          sessionFactory.getCurrentSession()
				.createCriteria(Category.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		
		return listCategory;
	}

	@Transactional
	public void addCategory(Category category) {
		sessionFactory.getCurrentSession().saveOrUpdate(category);
	}
	
	@Transactional
	public void updateCategory(Category category) {
		sessionFactory.getCurrentSession().saveOrUpdate(category);
	}

	@Transactional
	public void deleteCategory(int categoryId) {
		Category CategoryToDelete = new Category();
		CategoryToDelete.setCategoryId(categoryId);
		sessionFactory.getCurrentSession().delete(CategoryToDelete);
	}

	@Transactional
	public Category getCategorybyId(int categoryId) {
		
		String hql = "from Category where categoryId=" + "'"+ categoryId +"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Category> listCategory = (List<Category>) query.list();
		
		if (listCategory != null && !listCategory.isEmpty()) {
			return listCategory.get(0);
		}
	
		return null;
	}

	@Transactional
	public Category getCategorybyName(String categoryName) {
		String hql = "from Category where categoryName=" + "'"+ categoryName+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Category> list = (List<Category>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;
	}

}
