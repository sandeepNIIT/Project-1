package com.niit.mycartbackendproject.service.impl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.mycartbackendproject.dao.ProductDao;
import com.niit.mycartbackendproject.model.Product;
import com.niit.mycartbackendproject.service.ProductService;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductDao productDao;

    public Product getProductById(int productId){
        return productDao.getProductById(productId);
    }

    public List<Product> getProductList(){
        return productDao.getProductList();
    }

    public void addProduct(Product product){
        productDao.addProduct(product);
    }
    
    public void updateProduct(Product product){
        productDao.addProduct(product);
    }

    public void deleteProduct(int productId){
        productDao.deleteProduct(productId);
    }


} // The End of Class;
