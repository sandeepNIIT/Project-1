package com.niit.mycartbackendproject.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.niit.mycartbackendproject.dao.SupplierDao;
import com.niit.mycartbackendproject.model.Supplier;
import com.niit.mycartbackendproject.service.SupplierService;

@Service
public class SupplierServiceImpl implements SupplierService {
	
	@Autowired
    private SupplierDao supplierDao;


	public List<Supplier> getSupplierList() {
		 return supplierDao.getSupplierList();
	}

	
	public Supplier getSupplierbyId(int supplierId) {
		 return supplierDao.getSupplierbyId(supplierId);
		
	}

	
	public Supplier getSupplierbyName(String supplierName) {
		 return supplierDao.getSupplierbyName(supplierName);
		
	}

	
	public void addSupplier(Supplier supplier) {
		  supplierDao.addSupplier(supplier);
		
	}
	
	public void updateSupplier(Supplier supplier) {
		  supplierDao.addSupplier(supplier);
		
	}

	
	public String deleteSupplier(int supplierId) {
		 return supplierDao.deleteSupplier(supplierId);
		
	}
	
}
