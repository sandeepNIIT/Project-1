package com.niit.mycartbackendproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.niit.mycartbackendproject.model.Category;
import com.niit.mycartbackendproject.service.CategoryService;

@Controller
public class CategoryController {
	@Autowired
	private CategoryService categoryService;


	@RequestMapping(value = "/mancategories",method = RequestMethod.GET)
	public String listCategories(Model model) {
		model.addAttribute("AddCategory", true);
		model.addAttribute("categoryList", this.categoryService.getCategoryList());
		model.addAttribute("isAdminClickedCategories", "true");
		return "Home";
	}


	
	@RequestMapping(value = "/category/add", method = RequestMethod.POST)
	public String addCategory(@ModelAttribute("category") Category category,ModelMap model) {
		       categoryService.addCategory(category);
       
		return "redirect:/mancategories";
		

	}

	@RequestMapping("category/remove/{categoryId}")
	public String deleteCategory(@PathVariable("categoryId") int categoryId, ModelMap model) throws Exception {

		try {
			categoryService.deleteCategory(categoryId);
			
			model.addAttribute("message", "Successfully Added");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		
		return "redirect:/mancategories";
	}

	@RequestMapping(value="category/edit/{categoryId}",method = RequestMethod.GET)
	public String editCategory(@PathVariable("categoryId") int categoryId, ModelMap model) {
		
		 model.addAttribute("category", this.categoryService.getCategorybyId(categoryId));
		 model.addAttribute("EditCategory",true);
		model.addAttribute("categoryList", this.categoryService.getCategoryList());
		model.addAttribute("isAdminClickedCategories", "true");
		
		 return "Home";
	}
	@RequestMapping(value="/category/edit",method = RequestMethod.POST)
	public String editCategory(@ModelAttribute("category") Category category,ModelMap model) {
		
		 categoryService.updateCategory(category);
		
		model.addAttribute("categoryList", this.categoryService.getCategoryList());
		model.addAttribute("isAdminClickedCategories", "true");
		 return "redirect:/mancategories";
	}
	
}
