package com.niit.mycartbackendproject.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.niit.mycartbackendproject.model.BillingAddress;
import com.niit.mycartbackendproject.model.Customer;
import com.niit.mycartbackendproject.model.ShippingAddress;
import com.niit.mycartbackendproject.service.CustomerService;

@Controller
public class HomeController {

	@Autowired
	private CustomerService customerService;

	@RequestMapping(value = { "/", "/home" })
	public ModelAndView onLoad(HttpSession session) {

		ModelAndView mv = new ModelAndView("/Home");
		mv.addObject("display", true);

		return mv;

	}

	@RequestMapping(value = "userRegistration", method = RequestMethod.POST)
	public ModelAndView registerCustomerPost(@Valid @ModelAttribute("customer") Customer customer,
			BindingResult result) {
		ModelAndView mv = new ModelAndView("/Home");
		if (result.hasErrors()) {
			return mv;
		}

		List<Customer> customerList = customerService.getAllCustomers();

		for (int i = 0; i < customerList.size(); i++) {
			if (customer.getCustomerEmail().equals(customerList.get(i).getCustomerEmail())) {
				mv.addObject("emailMsg", "Email already exists");

				return mv;
			}

			if (customer.getUsername().equals(customerList.get(i).getUsername())) {
				mv.addObject("usernameMsg", "Username already exists");

				return mv;
			}
		}

		customer.setEnabled(true);
		mv.addObject("successMessage", "You are successfully registered.Please Login");
		mv.addObject("signup", "true");
		customerService.addCustomer(customer);
		return mv;
	}

	@RequestMapping(value = "/landing", method = RequestMethod.GET)
	public ModelAndView checkUser(HttpServletRequest request, HttpServletResponse response, HttpSession session)
			throws Exception {

		ModelAndView mv = new ModelAndView("Home");
		if (request.isUserInRole("ROLE_ADMIN")) {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String name = auth.getName(); // get logged in username
			session = request.getSession(true);
			session.setAttribute("loggedInUser", name);

			// session.invalidate();

			mv.addObject("isAdmin", "true");
			return mv;
		} else if (request.isUserInRole("ROLE_USER")) {
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			String name = auth.getName(); // get logged in username
			session = request.getSession(true);
			session.setAttribute("loggedInUser", name);

			mv.addObject("display", "true");
			return mv;
		} else {
			mv.addObject("display", "true");
		}
		return mv;
	}

	@RequestMapping("/registerHere")
	public ModelAndView registerHere() {
		Customer customer = new Customer();
		BillingAddress billingAddress = new BillingAddress();
		ShippingAddress shippingAddress = new ShippingAddress();
		customer.setBillingAddress(billingAddress);
		customer.setShippingAddress(shippingAddress);

		ModelAndView mv = new ModelAndView("/Home");
		mv.addObject("customer", customer);
		mv.addObject("ifClickedRegister", "true");
		return mv;
	}

	
	 @RequestMapping("/loginHere")
	    public ModelAndView login(
	            @RequestParam(value="error", required = false)
	            String error,
	            @RequestParam(value="logout", required = false)
	            String logout){
		 ModelAndView mv = new ModelAndView("/Home");
	        if(error != null){
	            mv.addObject("error", "Invalid username and password");
	        }

	        if (logout !=null){
	            mv.addObject("msg", "You have been logged out successfully");
	        }
	        mv.addObject("ifClickedLogin", "true");
	        return mv;
	    }
}
