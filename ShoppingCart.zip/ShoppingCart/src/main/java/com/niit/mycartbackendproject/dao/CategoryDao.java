package com.niit.mycartbackendproject.dao;

import java.util.List;

import com.niit.mycartbackendproject.model.Category;

public interface CategoryDao {
	public List<Category> getCategoryList();

	public Category getCategorybyId(int categoryId);
	
	public Category getCategorybyName(String categoryName);

	public void addCategory(Category category);
	
	public void updateCategory(Category category);

	public void deleteCategory(int categoryId);

}
