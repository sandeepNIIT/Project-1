package com.niit.mycartbackendproject.dao;


import java.util.List;

import com.niit.mycartbackendproject.model.Customer;

public interface CustomerDao {

    void addCustomer(Customer customer);
    
    void updateCustomer(Customer customer);

    Customer getCustomerById(int customerId);

    List<Customer> getAllCustomers();
    
    void deleteCustomer(int customerId);

    Customer getCustomerByUsername(String username);
}
