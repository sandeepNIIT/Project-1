package com.niit.mycartbackendproject.controller;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import com.niit.mycartbackendproject.model.Category;
import com.niit.mycartbackendproject.model.Product;
import com.niit.mycartbackendproject.model.Supplier;
import com.niit.mycartbackendproject.service.CategoryService;
import com.niit.mycartbackendproject.service.ProductService;
import com.niit.mycartbackendproject.service.SupplierService;



@Controller
public class ProductController {
	
	@Autowired
	private SupplierService supplierService;
	
	@Autowired
	private CategoryService categoryService;
	
	 @Autowired
	 private ProductService productService;
	
	@RequestMapping(value = "/manproducts", method = RequestMethod.GET)
	public String listProducts(Model model) {
		
		model.addAttribute("productList", this.productService.getProductList());
		model.addAttribute("AddProduct", true);
		model.addAttribute("categoryList", this.categoryService.getCategoryList());
		model.addAttribute("supplierList", this.supplierService.getSupplierList());
		model.addAttribute("isAdminClickedProducts", "true");
		return "Home";
	}
	@ModelAttribute("product")
	public Product pro1()
	{
		return new Product();
	}

	
	@RequestMapping(value = "/product/add", method = RequestMethod.POST)
	public String addProduct(HttpServletRequest request, @RequestParam CommonsMultipartFile[] imageUpload,@ModelAttribute("product")Product product,BindingResult result) {
		         
		        if (imageUpload != null && imageUpload.length > 0) {
		            for (CommonsMultipartFile aFile : imageUpload){
		                 
		                System.out.println("Saving file: " + aFile.getOriginalFilename());
		                
		               
		                product.setProductName(aFile.getOriginalFilename());
		               product.setProductImage(aFile.getBytes());
		                                
		            }
		        }
		        productService.addProduct(product);
		        return "redirect:/manproducts";
				}

		
		
	@RequestMapping("product/remove/{productId}")
	public String removeProduct(@PathVariable("productId") int productId, ModelMap model) throws Exception {

		try {
			productService.deleteProduct(productId);
			model.addAttribute("message", "Successfully Added");
		} catch (Exception e) {
			model.addAttribute("message", e.getMessage());
			e.printStackTrace();
		}
		// redirectAttrs.addFlashAttribute(arg0, arg1)
		return "redirect:/manproducts";
	}

	@RequestMapping("product/edit/{productId}")
	public String editProduct(@PathVariable("productId") int productId, Model model) {
		model.addAttribute("EditCategory", true);
		model.addAttribute("product", this.productService.getProductById(productId));
		model.addAttribute("productList", this.productService.getProductList());
		
		

		return "redirect:/manproducts";
	}
	
	@RequestMapping(value="/product/edit",method = RequestMethod.POST)
	public String editProduct(@ModelAttribute("product") Product product,ModelMap model) {
		
		 productService.updateProduct(product);
		model.addAttribute("productList", this.productService.getProductList());
		model.addAttribute("isAdminClickedProducts", "true");
		 return "redirect:/manproducts";
	}
	
	
	

}
