package com.niit.mycartbackendproject.service;

import com.niit.mycartbackendproject.model.Cart;

public interface CartService {

    Cart getCartById(int cartId);

    void update(Cart cart);
}
